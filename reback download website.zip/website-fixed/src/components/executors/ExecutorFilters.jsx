import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function ExecutorFilters({ filter, onChange }) {
  const set = (key, val) => onChange(prev => ({ ...prev, [key]: val }));

  return (
    <div className="flex flex-wrap gap-2">
      <Select value={filter.free} onValueChange={v => set('free', v)}>
        <SelectTrigger className="w-32 h-9 text-sm">
          <SelectValue placeholder="Price" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Prices</SelectItem>
          <SelectItem value="free">Free</SelectItem>
          <SelectItem value="paid">Paid</SelectItem>
        </SelectContent>
      </Select>

      <Select value={filter.detected} onValueChange={v => set('detected', v)}>
        <SelectTrigger className="w-36 h-9 text-sm">
          <SelectValue placeholder="Detection" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Status</SelectItem>
          <SelectItem value="safe">Undetected</SelectItem>
          <SelectItem value="detected">Detected</SelectItem>
        </SelectContent>
      </Select>

      <Select value={filter.updated} onValueChange={v => set('updated', v)}>
        <SelectTrigger className="w-36 h-9 text-sm">
          <SelectValue placeholder="Update" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Updates</SelectItem>
          <SelectItem value="updated">Updated</SelectItem>
          <SelectItem value="outdated">Outdated</SelectItem>
        </SelectContent>
      </Select>

      <Select value={filter.platform} onValueChange={v => set('platform', v)}>
        <SelectTrigger className="w-36 h-9 text-sm">
          <SelectValue placeholder="Platform" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Platforms</SelectItem>
          <SelectItem value="windows">Windows</SelectItem>
          <SelectItem value="mac">Mac</SelectItem>
          <SelectItem value="android">Android</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}