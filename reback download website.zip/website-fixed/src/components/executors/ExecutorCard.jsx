import { ExternalLink, MessageSquare, ShoppingCart, Shield, ShieldAlert, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default function ExecutorCard({ executor: e }) {
  const isDetected = e.detected;
  const isUpdated = e.updateStatus;

  return (
    <div className="rounded-xl border border-border bg-card p-5 flex flex-col gap-4 hover:border-primary/30 transition-all duration-200">
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="font-semibold text-foreground">{e.title}</h3>
          {e.version && <p className="text-xs text-muted-foreground mt-0.5">{e.version}</p>}
        </div>
        <div className="flex flex-col items-end gap-1.5 shrink-0">
          <Badge variant="outline" className={e.free ? 'text-green-400 border-green-400/30 bg-green-400/10' : 'text-amber-400 border-amber-400/30 bg-amber-400/10'}>
            {e.free ? 'Free' : e.cost || 'Paid'}
          </Badge>
          {e.platform && (
            <Badge variant="outline" className="text-xs text-muted-foreground">{e.platform}</Badge>
          )}
        </div>
      </div>

      {/* Status Row */}
      <div className="flex flex-wrap gap-2">
        <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border ${isDetected ? 'border-red-500/30 bg-red-500/10 text-red-400' : 'border-green-500/30 bg-green-500/10 text-green-400'}`}>
          {isDetected ? <ShieldAlert className="w-3 h-3" /> : <Shield className="w-3 h-3" />}
          {isDetected ? 'Detected' : 'Undetected'}
        </div>
        <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border ${isUpdated ? 'border-green-500/30 bg-green-500/10 text-green-400' : 'border-red-500/30 bg-red-500/10 text-red-400'}`}>
          {isUpdated ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
          {isUpdated ? 'Updated' : 'Outdated'}
        </div>
        {e.uncStatus && (
          <div className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border border-blue-500/30 bg-blue-500/10 text-blue-400">
            UNC
          </div>
        )}
      </div>

      {/* UNC/sUNC percentages */}
      {(e.uncPercentage != null || e.suncPercentage != null) && (
        <div className="flex gap-4 text-xs text-muted-foreground">
          {e.uncPercentage != null && (
            <div className="flex flex-col gap-1 flex-1">
              <span>UNC {e.uncPercentage}%</span>
              <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: `${e.uncPercentage}%` }} />
              </div>
            </div>
          )}
          {e.suncPercentage != null && (
            <div className="flex flex-col gap-1 flex-1">
              <span>sUNC {e.suncPercentage}%</span>
              <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-purple-500 rounded-full" style={{ width: `${e.suncPercentage}%` }} />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between pt-2 border-t border-border mt-auto">
        {e.updatedDate && (
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <RefreshCw className="w-3 h-3" />
            {e.updatedDate}
          </span>
        )}
        <div className="flex items-center gap-1 ml-auto">
          {e.websitelink && (
            <a href={e.websitelink} target="_blank" rel="noopener noreferrer">
              <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground hover:text-foreground">
                <ExternalLink className="w-3.5 h-3.5" />
              </Button>
            </a>
          )}
          {e.discordlink && (
            <a href={e.discordlink} target="_blank" rel="noopener noreferrer">
              <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground hover:text-foreground">
                <MessageSquare className="w-3.5 h-3.5" />
              </Button>
            </a>
          )}
          {e.purchaselink && !e.free && (
            <a href={e.purchaselink} target="_blank" rel="noopener noreferrer">
              <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground hover:text-foreground">
                <ShoppingCart className="w-3.5 h-3.5" />
              </Button>
            </a>
          )}
        </div>
      </div>
    </div>
  );
}