import { format } from 'date-fns';
import { Download, FileArchive, Monitor, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const typeConfig = {
  zip:   { icon: FileArchive, color: 'bg-blue-50 text-blue-600',   label: 'ZIP'  },
  rar:   { icon: FileArchive, color: 'bg-purple-50 text-purple-600', label: 'RAR' },
  '7z':  { icon: FileArchive, color: 'bg-indigo-50 text-indigo-600', label: '7Z'  },
  exe:   { icon: Monitor,     color: 'bg-orange-50 text-orange-600', label: 'EXE' },
  msi:   { icon: Package,     color: 'bg-green-50 text-green-600',   label: 'MSI' },
  other: { icon: FileArchive, color: 'bg-muted text-muted-foreground', label: 'FILE' },
};

export default function DownloadCard({ file }) {
  const cfg = typeConfig[file.file_type] || typeConfig.other;
  const Icon = cfg.icon;

  return (
    <div className="group rounded-xl border border-border bg-card p-5 flex flex-col gap-4 hover:shadow-md hover:border-primary/20 transition-all duration-200">
      <div className="flex items-start gap-3">
        <div className={`p-2.5 rounded-lg ${cfg.color} shrink-0`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground truncate">{file.name}</h3>
          {file.version && (
            <span className="text-xs text-muted-foreground">{file.version}</span>
          )}
        </div>
        <Badge variant="outline" className="text-xs shrink-0">{cfg.label}</Badge>
      </div>

      {file.description && (
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2">{file.description}</p>
      )}

      <div className="flex items-center justify-between text-xs text-muted-foreground mt-auto pt-2 border-t border-border">
        <div className="flex items-center gap-3">
          {file.file_size && <span>{file.file_size}</span>}
          {file.created_date && (
            <span>{format(new Date(file.created_date), 'MMM d, yyyy')}</span>
          )}
        </div>
        {file.category && (
          <span className="px-2 py-0.5 rounded-full bg-muted text-muted-foreground text-xs">{file.category}</span>
        )}
      </div>

      <a href={file.file_url} target="_blank" rel="noopener noreferrer" download>
        <Button className="w-full gap-2" size="sm">
          <Download className="w-4 h-4" />
          Download
        </Button>
      </a>
    </div>
  );
}