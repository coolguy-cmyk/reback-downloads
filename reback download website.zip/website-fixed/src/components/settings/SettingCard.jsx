import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

export default function SettingCard({ setting, isAdmin, editValues, onValueChange }) {
  const currentValue = editValues?.[setting.id] ?? setting.value;

  return (
    <div className={cn(
      "group rounded-xl border border-border bg-card p-5 transition-all duration-200",
      isAdmin && "hover:shadow-md hover:border-primary/20"
    )}>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex-1 min-w-0">
          <Label className="text-sm font-semibold text-foreground">{setting.label}</Label>
          {setting.description && (
            <p className="text-xs text-muted-foreground mt-0.5">{setting.description}</p>
          )}
        </div>
        <div className="sm:w-64 shrink-0">
          {isAdmin ? (
            <Input
              value={currentValue}
              onChange={(e) => onValueChange(setting.id, e.target.value)}
              className="text-sm"
            />
          ) : (
            <div className="px-3 py-2 rounded-lg bg-muted text-sm text-foreground truncate">
              {setting.value}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}