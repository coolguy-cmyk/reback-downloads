const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Upload } from 'lucide-react';
import { toast } from 'sonner';

const FILE_TYPES = ['zip', 'rar', '7z', 'exe', 'msi', 'other'];

export default function FileUploadDialog({ onClose, onSuccess }) {
  const [file, setFile] = useState(null);
  const [form, setForm] = useState({ name: '', description: '', file_type: 'zip', version: '', category: '' });
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    setFile(f);
    if (!form.name) setForm(prev => ({ ...prev, name: f.name.replace(/\.[^/.]+$/, '') }));
    // Auto detect file type
    const ext = f.name.split('.').pop().toLowerCase();
    if (FILE_TYPES.includes(ext)) setForm(prev => ({ ...prev, file_type: ext }));
    // Format size
    const size = f.size < 1024 * 1024
      ? `${(f.size / 1024).toFixed(1)} KB`
      : `${(f.size / (1024 * 1024)).toFixed(1)} MB`;
    setForm(prev => ({ ...prev, _size: size }));
  };

  const handleSubmit = async () => {
    if (!file || !form.name) return;
    setUploading(true);
    try {
      const { file_url } = await db.integrations.Core.UploadFile({ file });
      await db.entities.DownloadFile.create({
        name: form.name,
        description: form.description,
        file_url,
        file_type: form.file_type,
        version: form.version,
        category: form.category,
        file_size: form._size,
      });
      toast.success('File uploaded successfully');
      onSuccess();
    } catch (err) {
      console.error('Upload failed:', err);
      toast.error('Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add Download File</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* File picker */}
          <div className="space-y-1.5">
            <Label>File</Label>
            <label className="flex flex-col items-center justify-center w-full h-28 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-muted/40 transition-colors">
              <Upload className="w-5 h-5 text-muted-foreground mb-1" />
              <span className="text-sm text-muted-foreground">
                {file ? file.name : 'Click to select file'}
              </span>
              <input type="file" className="hidden" onChange={handleFileChange}
                accept=".zip,.rar,.7z,.exe,.msi" />
            </label>
          </div>

          <div className="space-y-1.5">
            <Label>Display Name</Label>
            <Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. MyApp Installer" />
          </div>

          <div className="space-y-1.5">
            <Label>Description <span className="text-muted-foreground">(optional)</span></Label>
            <Input value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="Short description" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>File Type</Label>
              <Select value={form.file_type} onValueChange={v => setForm(p => ({ ...p, file_type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FILE_TYPES.map(t => <SelectItem key={t} value={t}>{t.toUpperCase()}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Version <span className="text-muted-foreground">(optional)</span></Label>
              <Input value={form.version} onChange={e => setForm(p => ({ ...p, version: e.target.value }))} placeholder="e.g. v1.0.0" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Category <span className="text-muted-foreground">(optional)</span></Label>
            <Input value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} placeholder="e.g. Tools, Games, Utilities" />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={uploading}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!file || !form.name || uploading} className="gap-2">
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            {uploading ? 'Uploading...' : 'Upload'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}