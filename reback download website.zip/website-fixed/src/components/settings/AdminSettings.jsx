const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';

import { Button } from '@/components/ui/button';
import { Plus, Loader2 } from 'lucide-react';
import FileUploadDialog from './FileUploadDialog';
import FileManageTable from './FileManageTable';

export default function AdminSettings() {
  const [showUpload, setShowUpload] = useState(false);
  const queryClient = useQueryClient();

  const { data: files = [], isLoading } = useQuery({
    queryKey: ['downloadFiles'],
    queryFn: () => db.entities.DownloadFile.filter({}, '-created_date'),
  });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ['downloadFiles'] });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Settings</h1>
          <p className="text-muted-foreground mt-1">Manage downloadable files</p>
        </div>
        <Button onClick={() => setShowUpload(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          Add File
        </Button>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <FileManageTable files={files} onRefresh={refresh} />
      )}

      {showUpload && (
        <FileUploadDialog
          onClose={() => setShowUpload(false)}
          onSuccess={() => { setShowUpload(false); refresh(); }}
        />
      )}
    </div>
  );
}