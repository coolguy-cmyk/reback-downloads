import SettingCard from './SettingCard';

const categoryLabels = {
  general: 'General',
  notifications: 'Notifications',
  appearance: 'Appearance',
  security: 'Security',
};

export default function SettingsCategorySection({ category, settings, isAdmin, editValues, onValueChange }) {
  if (!settings || settings.length === 0) return null;

  return (
    <div>
      <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 px-1">
        {categoryLabels[category] || category}
      </h3>
      <div className="space-y-3">
        {settings.map((setting) => (
          <SettingCard
            key={setting.id}
            setting={setting}
            isAdmin={isAdmin}
            editValues={editValues}
            onValueChange={onValueChange}
          />
        ))}
      </div>
    </div>
  );
}