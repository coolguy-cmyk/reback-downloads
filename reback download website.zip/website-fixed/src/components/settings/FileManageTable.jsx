const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { format } from 'date-fns';
import { Trash2, FileArchive, Monitor, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

import { toast } from 'sonner';

const typeConfig = {
  zip:   { icon: FileArchive, color: 'bg-blue-50 text-blue-600' },
  rar:   { icon: FileArchive, color: 'bg-purple-50 text-purple-600' },
  '7z':  { icon: FileArchive, color: 'bg-indigo-50 text-indigo-600' },
  exe:   { icon: Monitor,     color: 'bg-orange-50 text-orange-600' },
  msi:   { icon: Package,     color: 'bg-green-50 text-green-600' },
  other: { icon: FileArchive, color: 'bg-muted text-muted-foreground' },
};

export default function FileManageTable({ files, onRefresh }) {
  const handleDelete = async (id) => {
    try {
      await db.entities.DownloadFile.delete(id);
      toast.success('File removed');
      onRefresh();
    } catch (err) {
      console.error('Delete failed:', err);
      toast.error('Failed to remove file.');
    }
  };

  if (files.length === 0) {
    return (
      <div className="text-center py-20 text-muted-foreground border border-dashed border-border rounded-xl">
        <p className="font-medium">No files yet</p>
        <p className="text-sm mt-1">Click "Add File" to upload your first file</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-muted/60 text-muted-foreground">
          <tr>
            <th className="text-left px-4 py-3 font-medium">File</th>
            <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Type</th>
            <th className="text-left px-4 py-3 font-medium hidden md:table-cell">Size</th>
            <th className="text-left px-4 py-3 font-medium hidden md:table-cell">Added</th>
            <th className="px-4 py-3" />
          </tr>
        </thead>
        <tbody className="divide-y divide-border bg-card">
          {files.map(file => {
            const cfg = typeConfig[file.file_type] || typeConfig.other;
            const Icon = cfg.icon;
            return (
              <tr key={file.id} className="hover:bg-muted/30 transition-colors">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-1.5 rounded-md ${cfg.color} shrink-0`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-foreground truncate max-w-[180px]">{file.name}</p>
                      {file.version && <p className="text-xs text-muted-foreground">{file.version}</p>}
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 hidden sm:table-cell">
                  <Badge variant="outline" className="text-xs uppercase">{file.file_type}</Badge>
                </td>
                <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">
                  {file.file_size || '—'}
                </td>
                <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">
                  {file.created_date ? format(new Date(file.created_date), 'MMM d, yyyy') : '—'}
                </td>
                <td className="px-4 py-3 text-right">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-muted-foreground hover:text-destructive"
                    onClick={() => handleDelete(file.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}