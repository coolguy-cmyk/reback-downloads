const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

import { Input } from '@/components/ui/input';
import { Search, Loader2 } from 'lucide-react';
import DownloadCard from '@/components/downloads/DownloadCard';

export default function Downloads() {
  const [search, setSearch] = useState('');

  const { data: files = [], isLoading } = useQuery({
    queryKey: ['downloadFiles'],
    queryFn: () => db.entities.DownloadFile.filter({}, '-created_date'),
  });

  const filtered = files.filter(f =>
    f.name?.toLowerCase().includes(search.toLowerCase()) ||
    f.description?.toLowerCase().includes(search.toLowerCase()) ||
    f.category?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Downloads</h1>
        <p className="text-muted-foreground mt-1">Browse and download available files</p>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search files..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-24 text-muted-foreground">
          <p className="text-lg font-medium">{search ? 'No results found' : 'No files available'}</p>
          <p className="text-sm mt-1">{search ? 'Try a different search term' : 'Check back later for new downloads'}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(file => (
            <DownloadCard key={file.id} file={file} />
          ))}
        </div>
      )}
    </div>
  );
}