import React, { useState } from 'react';
import { Lock, Eye, EyeOff } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import AdminSettings from '@/components/settings/AdminSettings';

// Set VITE_SETTINGS_PASSWORD in your .env file — never hardcode secrets in source code.
const SETTINGS_PASSWORD = import.meta.env.VITE_SETTINGS_PASSWORD;

export default function Settings() {
  const [input, setInput] = useState('');
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState(false);
  const [show, setShow] = useState(false);

  const handleUnlock = () => {
    if (!SETTINGS_PASSWORD) {
      console.warn('VITE_SETTINGS_PASSWORD is not set. Access blocked.');
      setError(true);
      return;
    }
    if (input === SETTINGS_PASSWORD) {
      setUnlocked(true);
      setError(false);
    } else {
      setError(true);
    }
  };

  if (unlocked) return <AdminSettings />;

  return (
    <div className="flex flex-col items-center justify-center py-32">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <div className="inline-flex items-center justify-center p-4 rounded-full bg-muted mb-4">
            <Lock className="w-7 h-7 text-muted-foreground" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">Settings</h2>
          <p className="text-muted-foreground text-sm mt-1">Enter the password to continue</p>
        </div>

        <div className="space-y-3">
          <div className="relative">
            <Input
              type={show ? 'text' : 'password'}
              placeholder="Password"
              value={input}
              onChange={e => { setInput(e.target.value); setError(false); }}
              onKeyDown={e => e.key === 'Enter' && handleUnlock()}
              className={error ? 'border-destructive focus-visible:ring-destructive' : ''}
            />
            <button
              type="button"
              onClick={() => setShow(s => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {error && <p className="text-sm text-destructive">Incorrect password</p>}
          <Button className="w-full" onClick={handleUnlock}>Unlock</Button>
        </div>
      </div>
    </div>
  );
}
