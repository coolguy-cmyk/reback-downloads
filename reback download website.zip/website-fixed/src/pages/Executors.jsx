import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Search, Loader2 } from 'lucide-react';
import ExecutorCard from '@/components/executors/ExecutorCard';
import ExecutorFilters from '@/components/executors/ExecutorFilters';

const WEAO_URL = 'https://weao.xyz/api/status/exploits';

const fetchExecutors = async () => {
  // Try direct fetch first (works if CORS is open or if running server-side)
  try {
    const res = await fetch(WEAO_URL, {
      headers: { 'User-Agent': 'WEAO-3PService' },
      mode: 'cors',
    });
    if (res.ok) return res.json();
  } catch (_) {
    // CORS blocked — fall through to proxy
  }

  // Fallback: route through a public CORS proxy
  const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(WEAO_URL)}`;
  const res = await fetch(proxyUrl);
  if (!res.ok) throw new Error(`WEAO API error: ${res.status} ${res.statusText}`);
  return res.json();
};

export default function Executors() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState({ free: 'all', detected: 'all', updated: 'all', platform: 'all' });

  const { data: executors = [], isLoading, isError } = useQuery({
    queryKey: ['executors'],
    queryFn: fetchExecutors,
    staleTime: 1000 * 60 * 5,
  });

  const filtered = executors.filter(e => {
    if (e.hidden) return false;
    if (search && !e.title?.toLowerCase().includes(search.toLowerCase())) return false;
    if (filter.free === 'free' && !e.free) return false;
    if (filter.free === 'paid' && e.free) return false;
    if (filter.detected === 'safe' && e.detected) return false;
    if (filter.detected === 'detected' && !e.detected) return false;
    if (filter.updated === 'updated' && !e.updateStatus) return false;
    if (filter.updated === 'outdated' && e.updateStatus) return false;
    if (filter.platform !== 'all' && e.platform?.toLowerCase() !== filter.platform) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Executors</h1>
        <p className="text-muted-foreground mt-1">Live status tracker powered by WEAO</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative max-w-sm w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search executors..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <ExecutorFilters filter={filter} onChange={setFilter} />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : isError ? (
        <div className="text-center py-24 text-muted-foreground">
          <p className="font-medium">Failed to load executor data</p>
          <p className="text-sm mt-1">The WEAO API may be rate-limited or unavailable. Try again shortly.</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-24 text-muted-foreground">
          <p className="font-medium">No executors match your filters</p>
        </div>
      ) : (
        <>
          <p className="text-xs text-muted-foreground">{filtered.length} executor{filtered.length !== 1 ? 's' : ''}</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(e => <ExecutorCard key={e._id} executor={e} />)}
          </div>
        </>
      )}
    </div>
  );
}